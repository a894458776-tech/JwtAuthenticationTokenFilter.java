/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonIpDynamicsAccountEndpointService
 */
package com.kylin.kton.admin.account.service;

import com.kylin.kton.system.service.IKtonIpDynamicsAccountEndpointService;

public interface IpDynamicsAccountEndpointService
extends IKtonIpDynamicsAccountEndpointService {
    public void addEndpoint(Long var1, Long var2, String var3);
}

