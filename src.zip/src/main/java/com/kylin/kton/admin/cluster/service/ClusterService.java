/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonClusterService
 */
package com.kylin.kton.admin.cluster.service;

import com.kylin.kton.system.service.IKtonClusterService;

public interface ClusterService
extends IKtonClusterService {
}

