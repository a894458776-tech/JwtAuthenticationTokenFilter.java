/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonClusterStatisVpsService
 */
package com.kylin.kton.admin.cluster.service;

import com.kylin.kton.system.service.IKtonClusterStatisVpsService;

public interface ClusterStatisVpsService
extends IKtonClusterStatisVpsService {
}

