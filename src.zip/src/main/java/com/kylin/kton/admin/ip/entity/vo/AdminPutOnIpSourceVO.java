/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.kylin.kton.admin.ip.entity.vo;

import lombok.Generated;

public class AdminPutOnIpSourceVO {
    @Generated
    public AdminPutOnIpSourceVO() {
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AdminPutOnIpSourceVO)) {
            return false;
        }
        AdminPutOnIpSourceVO other = (AdminPutOnIpSourceVO)o;
        return other.canEqual(this);
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof AdminPutOnIpSourceVO;
    }

    @Generated
    public int hashCode() {
        boolean result = true;
        return 1;
    }

    @Generated
    public String toString() {
        return "AdminPutOnIpSourceVO()";
    }
}

