/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonIpDynamicsConfigPlanService
 */
package com.kylin.kton.admin.ip.service;

import com.kylin.kton.system.service.IKtonIpDynamicsConfigPlanService;

public interface IpDynamicsConfigPlanService
extends IKtonIpDynamicsConfigPlanService {
}

