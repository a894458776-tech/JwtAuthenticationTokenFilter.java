/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonIpStaticAuthWhitelistService
 */
package com.kylin.kton.admin.ip.service;

import com.kylin.kton.system.service.IKtonIpStaticAuthWhitelistService;

public interface IpStaticAuthWhitelistService
extends IKtonIpStaticAuthWhitelistService {
}

