/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonIpStaticAuthorizationService
 */
package com.kylin.kton.admin.ip.service;

import com.kylin.kton.system.service.IKtonIpStaticAuthorizationService;

public interface IpStaticAuthorizationService
extends IKtonIpStaticAuthorizationService {
}

