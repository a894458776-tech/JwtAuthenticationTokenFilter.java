/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonIpStaticPricesService
 */
package com.kylin.kton.admin.ip.service;

import com.kylin.kton.system.service.IKtonIpStaticPricesService;

public interface IpStaticPricesService
extends IKtonIpStaticPricesService {
}

