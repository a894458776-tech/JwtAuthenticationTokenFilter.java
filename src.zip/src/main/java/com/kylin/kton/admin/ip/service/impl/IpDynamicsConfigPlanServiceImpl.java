/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonIpDynamicsConfigPlanServiceImpl
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.ip.service.impl;

import com.kylin.kton.admin.ip.service.IpDynamicsConfigPlanService;
import com.kylin.kton.system.service.impl.KtonIpDynamicsConfigPlanServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class IpDynamicsConfigPlanServiceImpl
extends KtonIpDynamicsConfigPlanServiceImpl
implements IpDynamicsConfigPlanService {
}

