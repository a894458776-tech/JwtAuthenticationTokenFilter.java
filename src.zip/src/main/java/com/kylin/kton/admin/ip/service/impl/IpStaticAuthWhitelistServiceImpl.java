/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonIpStaticAuthWhitelistServiceImpl
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.ip.service.impl;

import com.kylin.kton.admin.ip.service.IpStaticAuthWhitelistService;
import com.kylin.kton.system.service.impl.KtonIpStaticAuthWhitelistServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class IpStaticAuthWhitelistServiceImpl
extends KtonIpStaticAuthWhitelistServiceImpl
implements IpStaticAuthWhitelistService {
}

