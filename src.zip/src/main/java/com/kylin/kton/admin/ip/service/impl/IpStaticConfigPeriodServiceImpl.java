/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonIpStaticConfigPeriodServiceImpl
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.ip.service.impl;

import com.kylin.kton.admin.ip.service.IpStaticConfigPeriodService;
import com.kylin.kton.system.service.impl.KtonIpStaticConfigPeriodServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class IpStaticConfigPeriodServiceImpl
extends KtonIpStaticConfigPeriodServiceImpl
implements IpStaticConfigPeriodService {
}

