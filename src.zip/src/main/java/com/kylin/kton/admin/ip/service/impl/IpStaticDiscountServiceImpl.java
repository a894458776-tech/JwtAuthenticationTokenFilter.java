/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonIpStaticDiscountServiceImpl
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.ip.service.impl;

import com.kylin.kton.admin.ip.service.IpStaticDiscountService;
import com.kylin.kton.system.service.impl.KtonIpStaticDiscountServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class IpStaticDiscountServiceImpl
extends KtonIpStaticDiscountServiceImpl
implements IpStaticDiscountService {
}

