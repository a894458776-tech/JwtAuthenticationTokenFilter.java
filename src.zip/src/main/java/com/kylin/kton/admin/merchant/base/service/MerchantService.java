/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.domain.KtonMerchant
 *  com.kylin.kton.system.service.IKtonMerchantService
 */
package com.kylin.kton.admin.merchant.base.service;

import com.kylin.kton.system.domain.KtonMerchant;
import com.kylin.kton.system.service.IKtonMerchantService;

public interface MerchantService
extends IKtonMerchantService {
    public int add(KtonMerchant var1);
}

