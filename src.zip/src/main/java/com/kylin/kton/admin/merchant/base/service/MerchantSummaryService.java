/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonMerchantSummaryService
 */
package com.kylin.kton.admin.merchant.base.service;

import com.kylin.kton.system.service.IKtonMerchantSummaryService;

public interface MerchantSummaryService
extends IKtonMerchantSummaryService {
}

