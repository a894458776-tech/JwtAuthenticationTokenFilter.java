/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonMerchantWalletItemService
 */
package com.kylin.kton.admin.merchant.base.service;

import com.kylin.kton.system.service.IKtonMerchantWalletItemService;

public interface MerchantWalletItemService
extends IKtonMerchantWalletItemService {
}

