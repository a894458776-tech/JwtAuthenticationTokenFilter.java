/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonMerchantSummaryServiceImpl
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.merchant.base.service.impl;

import com.kylin.kton.admin.merchant.base.service.MerchantSummaryService;
import com.kylin.kton.system.service.impl.KtonMerchantSummaryServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class MerchantSummaryServiceImpl
extends KtonMerchantSummaryServiceImpl
implements MerchantSummaryService {
}

