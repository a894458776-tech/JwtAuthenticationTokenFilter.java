/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonMerchantWalletItemServiceImpl
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.merchant.base.service.impl;

import com.kylin.kton.admin.merchant.base.service.MerchantWalletItemService;
import com.kylin.kton.system.service.impl.KtonMerchantWalletItemServiceImpl;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class MerchantWalletItemServiceImpl
extends KtonMerchantWalletItemServiceImpl
implements MerchantWalletItemService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(MerchantWalletItemServiceImpl.class);
}

