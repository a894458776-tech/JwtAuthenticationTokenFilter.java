/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.IKtonOrderItemStaticService
 */
package com.kylin.kton.admin.order.service;

import com.kylin.kton.system.service.IKtonOrderItemStaticService;

public interface OrderItemStaticService
extends IKtonOrderItemStaticService {
}

