/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.kylin.kton.system.service.impl.KtonOrderItemStaticServiceImpl
 *  lombok.Generated
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Service
 */
package com.kylin.kton.admin.order.service.impl;

import com.kylin.kton.admin.order.service.OrderItemStaticService;
import com.kylin.kton.system.service.impl.KtonOrderItemStaticServiceImpl;
import lombok.Generated;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceItemStaticImpl
extends KtonOrderItemStaticServiceImpl
implements OrderItemStaticService {
    @Generated
    private static final Logger log = LoggerFactory.getLogger(OrderServiceItemStaticImpl.class);
}

