package com.kylin.kton.admin.server.service;

import com.kylin.kton.admin.server.domain.SysApiInstance;
import com.kylin.kton.admin.server.domain.SysServer;
import com.kylin.kton.admin.server.mapper.ApiInstanceMapper;
import com.kylin.kton.admin.server.mapper.ServerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class ServerService {

    @Autowired
    private ServerMapper serverMapper;

    @Autowired
    private ApiInstanceMapper apiInstanceMapper;

    // 如果您没有全局配置 RestTemplate，可以在这里简单定义一个
    // 建议放在全局 Config 类中
    private RestTemplate restTemplate = new RestTemplate();

    public List<SysServer> getServerList() {
        return serverMapper.selectServerList();
    }

    // ⭐ 1. 创建订单 + 调用上游 /addStatic
    @Transactional
    public void createApiInstanceOrder(Long merchantId, String nodeIp, String username, String password, String assignedIp, int days, String remark) {
        // 1. 查找目标服务器信息
        SysServer server = serverMapper.selectServerByIp(nodeIp);
        if (server == null) {
            throw new RuntimeException("Target server node (" + nodeIp + ") does not exist.");
        }

        // 2. 调用上游 API 开通资源
        // URL: http://{ip}:{port}/api/kton/admin/order/addStatic
        String url = String.format("http://%s:%d/api/kton/admin/order/addStatic", server.getIp(), server.getPort());

        Map<String, Object> payload = new HashMap<>();
        payload.put("token", server.getToken()); // 将服务器 Token 传过去
        payload.put("merchantId", merchantId);
        payload.put("days", days);
        payload.put("ips", Collections.singletonList(assignedIp)); // 上游要求 ips 是数组
        payload.put("isExclusive", 0);

        Map response = sendPostRequest(url, payload);
        if (!isSuccess(response)) {
            throw new RuntimeException("上游开通失败: " + getErrorMsg(response));
        }

        // 3. 上游成功后，写入本地数据库
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, days);
        Date expireTime = c.getTime();

        SysApiInstance instance = new SysApiInstance();
        instance.setMerchantId(merchantId);
        instance.setServerId(server.getId()); // 记录是哪个服务器
        instance.setUsername(username);
        instance.setPassword(password);
        instance.setAssignedIp(assignedIp); // 记录分配的 IP
        instance.setNote(remark);
        instance.setExpireTime(expireTime);

        apiInstanceMapper.insertInstance(instance);
    }

    // ⭐ 2. 续费 + 调用上游 /renewIpList
    public void renewApiInstance(String username, int addDays, int monthCount) {
        // 1. 查找本地记录
        SysApiInstance instance = apiInstanceMapper.selectByUsername(username);
        if (instance == null) throw new RuntimeException("Local instance not found for user: " + username);

        // 2. 查找所属服务器
        SysServer server = serverMapper.selectServerById(instance.getServerId());
        if (server == null) throw new RuntimeException("Associated server not found.");

        // 3. 调用上游 API
        String url = String.format("http://%s:%d/api/kton/admin/order/renewIpList", server.getIp(), server.getPort());

        Map<String, Object> payload = new HashMap<>();
        payload.put("token", server.getToken());
        payload.put("merchantId", instance.getMerchantId());
        payload.put("ipList", Collections.singletonList(instance.getAssignedIp())); // 使用本地记录的 IP
        payload.put("monthCount", monthCount);

        Map response = sendPostRequest(url, payload);
        if (!isSuccess(response)) {
            throw new RuntimeException("上游续费失败: " + getErrorMsg(response));
        }

        // 4. 更新本地数据库过期时间
        Calendar c = Calendar.getInstance();
        c.setTime(instance.getExpireTime());
        c.add(Calendar.DAY_OF_MONTH, addDays);
        apiInstanceMapper.renewInstance(username, c.getTime());
    }

    public void updateApiInstance(String oldUsername, String newUsername, String password, String note) {
        apiInstanceMapper.updateInstanceInfo(oldUsername, newUsername, password, note);
    }

    // ⭐ 3. 退订 + 调用上游 /unsubscribeStaticStrIps
    public void unsubscribeApiInstance(String username) {
        // 1. 查找本地记录
        SysApiInstance instance = apiInstanceMapper.selectByUsername(username);
        if (instance == null) throw new RuntimeException("Local instance not found.");

        // 2. 查找所属服务器
        SysServer server = serverMapper.selectServerById(instance.getServerId());
        if (server == null) throw new RuntimeException("Server not found.");

        // 3. 调用上游 API
        String url = String.format("http://%s:%d/api/kton/admin/order/unsubscribeStaticStrIps", server.getIp(), server.getPort());

        Map<String, Object> payload = new HashMap<>();
        payload.put("token", server.getToken());
        payload.put("merchantId", instance.getMerchantId());
        payload.put("ipList", instance.getAssignedIp()); // 上游退订接口只要字符串，不要数组

        Map response = sendPostRequest(url, payload);
        if (!isSuccess(response)) {
            throw new RuntimeException("上游退订失败: " + getErrorMsg(response));
        }

        // 4. 更新本地数据库状态
        apiInstanceMapper.deleteInstance(username);
    }

    // --- HTTP 工具方法 ---
    private Map sendPostRequest(String url, Map<String, Object> params) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(params, headers);
        try {
            return restTemplate.postForEntity(url, request, Map.class).getBody();
        } catch (Exception e) {
            throw new RuntimeException("Network error calling " + url + ": " + e.getMessage());
        }
    }

    private boolean isSuccess(Map response) {
        return response != null && Integer.valueOf(200).equals(response.get("code"));
    }

    private String getErrorMsg(Map response) {
        return response != null ? String.valueOf(response.get("msg")) : "Unknown error";
    }
}