/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.kylin.kton.api.netnut.entity.subuser;

import lombok.Generated;

public class TrafficAvailableCountriesMobRequest {
    @Generated
    public TrafficAvailableCountriesMobRequest() {
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof TrafficAvailableCountriesMobRequest)) {
            return false;
        }
        TrafficAvailableCountriesMobRequest other = (TrafficAvailableCountriesMobRequest)o;
        return other.canEqual(this);
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof TrafficAvailableCountriesMobRequest;
    }

    @Generated
    public int hashCode() {
        boolean result = true;
        return 1;
    }

    @Generated
    public String toString() {
        return "TrafficAvailableCountriesMobRequest()";
    }
}

