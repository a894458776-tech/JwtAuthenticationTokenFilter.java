/*
 * Decompiled with CFR 0.152.
 */
package com.kylin.kton.api.oxylabs.entity;

public class ClientStatsResponse {
}

