/*
 * Decompiled with CFR 0.152.
 */
package com.kylin.kton.api.oxylabs.properties;

public class TargetStatsResponse {
}

