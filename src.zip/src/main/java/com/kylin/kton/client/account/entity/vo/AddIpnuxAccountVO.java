/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.kylin.kton.client.account.entity.vo;

import lombok.Generated;

public class AddIpnuxAccountVO {
    @Generated
    public AddIpnuxAccountVO() {
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof AddIpnuxAccountVO)) {
            return false;
        }
        AddIpnuxAccountVO other = (AddIpnuxAccountVO)o;
        return other.canEqual(this);
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof AddIpnuxAccountVO;
    }

    @Generated
    public int hashCode() {
        boolean result = true;
        return 1;
    }

    @Generated
    public String toString() {
        return "AddIpnuxAccountVO()";
    }
}

