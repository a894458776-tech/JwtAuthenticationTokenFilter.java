/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.annotation.JsonFormat
 *  lombok.Generated
 */
package com.kylin.kton.client.cluster.entity.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import lombok.Generated;

public class ContainerParamListDTO {
    private Long containerId;
    private Long hostId;
    private Long hostTemplateId;
    private Long activationDurationType;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date effectiveDatetime;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date expireDatetime;
    private String model;
    private Long cpuCores;
    private String cpuModel;
    private Long memory;
    private Long diskCapacity;
    private String diskModel;
    private Long ioWrite;
    private Long ioRead;
    private Long bandwidth;
    private Long internetTraffic;
    private String ipV4;
    private String ipV6;

    @Generated
    public ContainerParamListDTO() {
    }

    @Generated
    public Long getContainerId() {
        return this.containerId;
    }

    @Generated
    public Long getHostId() {
        return this.hostId;
    }

    @Generated
    public Long getHostTemplateId() {
        return this.hostTemplateId;
    }

    @Generated
    public Long getActivationDurationType() {
        return this.activationDurationType;
    }

    @Generated
    public Date getEffectiveDatetime() {
        return this.effectiveDatetime;
    }

    @Generated
    public Date getExpireDatetime() {
        return this.expireDatetime;
    }

    @Generated
    public String getModel() {
        return this.model;
    }

    @Generated
    public Long getCpuCores() {
        return this.cpuCores;
    }

    @Generated
    public String getCpuModel() {
        return this.cpuModel;
    }

    @Generated
    public Long getMemory() {
        return this.memory;
    }

    @Generated
    public Long getDiskCapacity() {
        return this.diskCapacity;
    }

    @Generated
    public String getDiskModel() {
        return this.diskModel;
    }

    @Generated
    public Long getIoWrite() {
        return this.ioWrite;
    }

    @Generated
    public Long getIoRead() {
        return this.ioRead;
    }

    @Generated
    public Long getBandwidth() {
        return this.bandwidth;
    }

    @Generated
    public Long getInternetTraffic() {
        return this.internetTraffic;
    }

    @Generated
    public String getIpV4() {
        return this.ipV4;
    }

    @Generated
    public String getIpV6() {
        return this.ipV6;
    }

    @Generated
    public void setContainerId(Long containerId) {
        this.containerId = containerId;
    }

    @Generated
    public void setHostId(Long hostId) {
        this.hostId = hostId;
    }

    @Generated
    public void setHostTemplateId(Long hostTemplateId) {
        this.hostTemplateId = hostTemplateId;
    }

    @Generated
    public void setActivationDurationType(Long activationDurationType) {
        this.activationDurationType = activationDurationType;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    @Generated
    public void setEffectiveDatetime(Date effectiveDatetime) {
        this.effectiveDatetime = effectiveDatetime;
    }

    @JsonFormat(pattern="yyyy-MM-dd")
    @Generated
    public void setExpireDatetime(Date expireDatetime) {
        this.expireDatetime = expireDatetime;
    }

    @Generated
    public void setModel(String model) {
        this.model = model;
    }

    @Generated
    public void setCpuCores(Long cpuCores) {
        this.cpuCores = cpuCores;
    }

    @Generated
    public void setCpuModel(String cpuModel) {
        this.cpuModel = cpuModel;
    }

    @Generated
    public void setMemory(Long memory) {
        this.memory = memory;
    }

    @Generated
    public void setDiskCapacity(Long diskCapacity) {
        this.diskCapacity = diskCapacity;
    }

    @Generated
    public void setDiskModel(String diskModel) {
        this.diskModel = diskModel;
    }

    @Generated
    public void setIoWrite(Long ioWrite) {
        this.ioWrite = ioWrite;
    }

    @Generated
    public void setIoRead(Long ioRead) {
        this.ioRead = ioRead;
    }

    @Generated
    public void setBandwidth(Long bandwidth) {
        this.bandwidth = bandwidth;
    }

    @Generated
    public void setInternetTraffic(Long internetTraffic) {
        this.internetTraffic = internetTraffic;
    }

    @Generated
    public void setIpV4(String ipV4) {
        this.ipV4 = ipV4;
    }

    @Generated
    public void setIpV6(String ipV6) {
        this.ipV6 = ipV6;
    }

    @Generated
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof ContainerParamListDTO)) {
            return false;
        }
        ContainerParamListDTO other = (ContainerParamListDTO)o;
        if (!other.canEqual(this)) {
            return false;
        }
        Long this$containerId = this.getContainerId();
        Long other$containerId = other.getContainerId();
        if (this$containerId == null ? other$containerId != null : !((Object)this$containerId).equals(other$containerId)) {
            return false;
        }
        Long this$hostId = this.getHostId();
        Long other$hostId = other.getHostId();
        if (this$hostId == null ? other$hostId != null : !((Object)this$hostId).equals(other$hostId)) {
            return false;
        }
        Long this$hostTemplateId = this.getHostTemplateId();
        Long other$hostTemplateId = other.getHostTemplateId();
        if (this$hostTemplateId == null ? other$hostTemplateId != null : !((Object)this$hostTemplateId).equals(other$hostTemplateId)) {
            return false;
        }
        Long this$activationDurationType = this.getActivationDurationType();
        Long other$activationDurationType = other.getActivationDurationType();
        if (this$activationDurationType == null ? other$activationDurationType != null : !((Object)this$activationDurationType).equals(other$activationDurationType)) {
            return false;
        }
        Long this$cpuCores = this.getCpuCores();
        Long other$cpuCores = other.getCpuCores();
        if (this$cpuCores == null ? other$cpuCores != null : !((Object)this$cpuCores).equals(other$cpuCores)) {
            return false;
        }
        Long this$memory = this.getMemory();
        Long other$memory = other.getMemory();
        if (this$memory == null ? other$memory != null : !((Object)this$memory).equals(other$memory)) {
            return false;
        }
        Long this$diskCapacity = this.getDiskCapacity();
        Long other$diskCapacity = other.getDiskCapacity();
        if (this$diskCapacity == null ? other$diskCapacity != null : !((Object)this$diskCapacity).equals(other$diskCapacity)) {
            return false;
        }
        Long this$ioWrite = this.getIoWrite();
        Long other$ioWrite = other.getIoWrite();
        if (this$ioWrite == null ? other$ioWrite != null : !((Object)this$ioWrite).equals(other$ioWrite)) {
            return false;
        }
        Long this$ioRead = this.getIoRead();
        Long other$ioRead = other.getIoRead();
        if (this$ioRead == null ? other$ioRead != null : !((Object)this$ioRead).equals(other$ioRead)) {
            return false;
        }
        Long this$bandwidth = this.getBandwidth();
        Long other$bandwidth = other.getBandwidth();
        if (this$bandwidth == null ? other$bandwidth != null : !((Object)this$bandwidth).equals(other$bandwidth)) {
            return false;
        }
        Long this$internetTraffic = this.getInternetTraffic();
        Long other$internetTraffic = other.getInternetTraffic();
        if (this$internetTraffic == null ? other$internetTraffic != null : !((Object)this$internetTraffic).equals(other$internetTraffic)) {
            return false;
        }
        Date this$effectiveDatetime = this.getEffectiveDatetime();
        Date other$effectiveDatetime = other.getEffectiveDatetime();
        if (this$effectiveDatetime == null ? other$effectiveDatetime != null : !((Object)this$effectiveDatetime).equals(other$effectiveDatetime)) {
            return false;
        }
        Date this$expireDatetime = this.getExpireDatetime();
        Date other$expireDatetime = other.getExpireDatetime();
        if (this$expireDatetime == null ? other$expireDatetime != null : !((Object)this$expireDatetime).equals(other$expireDatetime)) {
            return false;
        }
        String this$model = this.getModel();
        String other$model = other.getModel();
        if (this$model == null ? other$model != null : !this$model.equals(other$model)) {
            return false;
        }
        String this$cpuModel = this.getCpuModel();
        String other$cpuModel = other.getCpuModel();
        if (this$cpuModel == null ? other$cpuModel != null : !this$cpuModel.equals(other$cpuModel)) {
            return false;
        }
        String this$diskModel = this.getDiskModel();
        String other$diskModel = other.getDiskModel();
        if (this$diskModel == null ? other$diskModel != null : !this$diskModel.equals(other$diskModel)) {
            return false;
        }
        String this$ipV4 = this.getIpV4();
        String other$ipV4 = other.getIpV4();
        if (this$ipV4 == null ? other$ipV4 != null : !this$ipV4.equals(other$ipV4)) {
            return false;
        }
        String this$ipV6 = this.getIpV6();
        String other$ipV6 = other.getIpV6();
        return !(this$ipV6 == null ? other$ipV6 != null : !this$ipV6.equals(other$ipV6));
    }

    @Generated
    protected boolean canEqual(Object other) {
        return other instanceof ContainerParamListDTO;
    }

    @Generated
    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Long $containerId = this.getContainerId();
        result = result * 59 + ($containerId == null ? 43 : ((Object)$containerId).hashCode());
        Long $hostId = this.getHostId();
        result = result * 59 + ($hostId == null ? 43 : ((Object)$hostId).hashCode());
        Long $hostTemplateId = this.getHostTemplateId();
        result = result * 59 + ($hostTemplateId == null ? 43 : ((Object)$hostTemplateId).hashCode());
        Long $activationDurationType = this.getActivationDurationType();
        result = result * 59 + ($activationDurationType == null ? 43 : ((Object)$activationDurationType).hashCode());
        Long $cpuCores = this.getCpuCores();
        result = result * 59 + ($cpuCores == null ? 43 : ((Object)$cpuCores).hashCode());
        Long $memory = this.getMemory();
        result = result * 59 + ($memory == null ? 43 : ((Object)$memory).hashCode());
        Long $diskCapacity = this.getDiskCapacity();
        result = result * 59 + ($diskCapacity == null ? 43 : ((Object)$diskCapacity).hashCode());
        Long $ioWrite = this.getIoWrite();
        result = result * 59 + ($ioWrite == null ? 43 : ((Object)$ioWrite).hashCode());
        Long $ioRead = this.getIoRead();
        result = result * 59 + ($ioRead == null ? 43 : ((Object)$ioRead).hashCode());
        Long $bandwidth = this.getBandwidth();
        result = result * 59 + ($bandwidth == null ? 43 : ((Object)$bandwidth).hashCode());
        Long $internetTraffic = this.getInternetTraffic();
        result = result * 59 + ($internetTraffic == null ? 43 : ((Object)$internetTraffic).hashCode());
        Date $effectiveDatetime = this.getEffectiveDatetime();
        result = result * 59 + ($effectiveDatetime == null ? 43 : ((Object)$effectiveDatetime).hashCode());
        Date $expireDatetime = this.getExpireDatetime();
        result = result * 59 + ($expireDatetime == null ? 43 : ((Object)$expireDatetime).hashCode());
        String $model = this.getModel();
        result = result * 59 + ($model == null ? 43 : $model.hashCode());
        String $cpuModel = this.getCpuModel();
        result = result * 59 + ($cpuModel == null ? 43 : $cpuModel.hashCode());
        String $diskModel = this.getDiskModel();
        result = result * 59 + ($diskModel == null ? 43 : $diskModel.hashCode());
        String $ipV4 = this.getIpV4();
        result = result * 59 + ($ipV4 == null ? 43 : $ipV4.hashCode());
        String $ipV6 = this.getIpV6();
        result = result * 59 + ($ipV6 == null ? 43 : $ipV6.hashCode());
        return result;
    }

    @Generated
    public String toString() {
        return "ContainerParamListDTO(containerId=" + this.getContainerId() + ", hostId=" + this.getHostId() + ", hostTemplateId=" + this.getHostTemplateId() + ", activationDurationType=" + this.getActivationDurationType() + ", effectiveDatetime=" + this.getEffectiveDatetime() + ", expireDatetime=" + this.getExpireDatetime() + ", model=" + this.getModel() + ", cpuCores=" + this.getCpuCores() + ", cpuModel=" + this.getCpuModel() + ", memory=" + this.getMemory() + ", diskCapacity=" + this.getDiskCapacity() + ", diskModel=" + this.getDiskModel() + ", ioWrite=" + this.getIoWrite() + ", ioRead=" + this.getIoRead() + ", bandwidth=" + this.getBandwidth() + ", internetTraffic=" + this.getInternetTraffic() + ", ipV4=" + this.getIpV4() + ", ipV6=" + this.getIpV6() + ")";
    }
}

